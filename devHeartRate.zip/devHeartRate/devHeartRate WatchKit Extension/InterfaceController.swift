//
//  InterfaceController.swift
//  devHeartRate WatchKit Extension
//
//  Created by Hatim HEBBOUL on 08/03/2021.
//

import WatchKit
import Foundation
import HealthKit

class InterfaceController: WKInterfaceController {
    
    @IBOutlet weak var labelHR : WKInterfaceLabel?
    @IBOutlet weak var date : WKInterfaceLabel?
    @IBOutlet weak var lancer: WKInterfaceButton?
    @IBOutlet weak var arreter : WKInterfaceButton?
    var timer : Timer?
    var test : Int = 0
    let health : HKHealthStore = HKHealthStore()
    let heartRateUnit : HKUnit = HKUnit(from: "count/min")

    let heartRateType : HKQuantityType = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!

    var heartRateQuery : HKQuery?

    override func awake(withContext context: Any?) {
        let readingTypes : Set = Set([heartRateType])
        let writingTypes : Set = Set([ heartRateType])
        health.requestAuthorization(toShare :writingTypes ,read : readingTypes) { (success,error)->Void in
            if error != nil
        {
                print ( " error \(String(describing: error?.localizedDescription)) " )
        }
        }
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }

    
    @IBAction func lancer(_sender:WKInterfaceObject) {

        self.arreter?.setEnabled(true)
        self.lancer?.setEnabled(false)
        
        test = 0
        timer = Timer.scheduledTimer(timeInterval: 10.0,target : self,selector: #selector( mesureDonnees),userInfo : nil , repeats : true )
    
    }
    
    
    @IBAction func arreter(_sender:WKInterfaceObject) {
        
        timer?.invalidate()
        timer=nil
    
        self.arreter?.setEnabled(false)
        self.lancer?.setEnabled(true)
    
    }
    
    @objc func mesureDonnees(timer: Timer ) {
        
        let queryPredicate: NSPredicate = HKQuery.predicateForSamples(withStart :NSDate() as Date ,end : nil , options : [ ] )
        let query:HKAnchoredObjectQuery=HKAnchoredObjectQuery(type: self.heartRateType,predicate: queryPredicate, anchor: nil,limit: Int(HKObjectQueryNoLimit))
        {(query:HKAnchoredObjectQuery,samples:[HKSample]? ,deletedObjects:[HKDeletedObject]?,anchor:HKQueryAnchor?,error:Error?)->Void in
            if let errorFound : Error = error
            {
                print( " query error:\(errorFound.localizedDescription) " )
            }
            else
            {
                if let samples = samples as? [ HKQuantitySample ]
                {
                    if let quantity = samples.last?.quantity
                    {
                        self.labelHR?.setText( " \(quantity.doubleValue(for: self.heartRateUnit))")
                        let formatteur = DateFormatter()
                        formatteur.dateFormat = "hh:mm:ss"
                        self.date?.setText( formatteur.string(from : Date() ) )

                    }
                }
            }
        }
        
            query.updateHandler =
          { (query : HKAnchoredObjectQuery , samples : [HKSample]? , deletedObjects:[HKDeletedObject]? , anchor : HKQueryAnchor? , error : Error? ) -> Void in
            
            if let errorFound : Error = error
            {
            print( " query−handler error :  \(errorFound.localizedDescription ) " )
            }
            else
            {
                if let samples = samples as? [HKQuantitySample]
                {
                    if let quantity = samples.last?.quantity
                    {
                        self.labelHR?.setText(" \(quantity.doubleValue( for :self.heartRateUnit) ) " )
                        let formatteur = DateFormatter()
                        formatteur.dateFormat = "hh:mm:ss"
                        self.date?.setText(formatteur.string(from : Date()))
                    }
                }
            }
        }
        health.execute(query)
}
    
    
    
}



