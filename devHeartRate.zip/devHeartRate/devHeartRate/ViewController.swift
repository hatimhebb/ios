//
//  ViewController.swift
//  devHeartRate
//
//  Created by Hatim HEBBOUL on 08/03/2021.
//

import UIKit
import HealthKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let health : HKHealthStore = HKHealthStore()
        let heartRateType :HKQuantityType = HKQuantityType.quantityType(forIdentifier:HKQuantityTypeIdentifier.heartRate)!
        let readingTypes : Set = Set([heartRateType])
        let writingTypes : Set = Set([heartRateType])
        health.requestAuthorization(toShare : writingTypes, read : readingTypes){(success ,
        error )->Void in
            if error != nil
            {
                print( " error \(String(describing : error?.localizedDescription)) " )
        // Do any additional setup after loading the view.
            }

        }
   }

}
